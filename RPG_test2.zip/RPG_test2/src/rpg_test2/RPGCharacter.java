package rpg_test2;

interface RPGCharacter {
    Arma getArma();
    Habilidade getHabilidade();
    Equipamento getEquipamento();
}