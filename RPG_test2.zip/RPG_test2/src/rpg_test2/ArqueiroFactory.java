package rpg_test2;

class ArqueiroFactory extends CharacterFactory {

    ArqueiroFactory() {
    }
    @Override
    public RPGCharacter createCharacter() {
        return new Arqueiro(new Arco(), new AtirarFlecha(), new ArmaduraLeve());
    }
}