package rpg_test2;

public abstract class CharacterFactory {
    public abstract RPGCharacter createCharacter();

    public static CharacterFactory getFactory(int characterType) {
        switch (characterType) {
            case 1:
                return new MagoFactory();
            case 2:
                return new GuerreiroFactory();
            case 3:
                return new ArqueiroFactory();
            default:
                throw new IllegalArgumentException("Tipo de personagem inválido");
        }
    }
}