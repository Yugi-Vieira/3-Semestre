package rpg_test2;

class AtirarFlecha implements Habilidade {
    @Override
    public void usar() {
        System.out.println("Usando atirar flecha");
    }
    @Override
    public String getName() {
        return "Atirar Flecha";
    }
}
