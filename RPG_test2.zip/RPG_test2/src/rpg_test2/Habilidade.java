package rpg_test2;

public interface Habilidade {
    void usar();
    String getName();
}
