package rpg_test2;

class Arqueiro implements RPGCharacter {
    private final Arco arma;
    private final AtirarFlecha habilidade;
    private final ArmaduraLeve equipamento;

    public Arqueiro(Arco arma, AtirarFlecha habilidade, ArmaduraLeve equipamento) {
        this.arma = arma;
        this.habilidade = habilidade;
        this.equipamento = equipamento;
    }

    @Override
    public Arma getArma() {
        return arma;
    }

    @Override
    public Habilidade getHabilidade() {
        return habilidade;
    }

    @Override
    public Equipamento getEquipamento() {
        return equipamento;
    }
}
