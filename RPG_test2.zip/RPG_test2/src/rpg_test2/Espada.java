package rpg_test2;

class Espada implements Arma {
    @Override
    public void usar() {
        System.out.println("Usando espada");
    }
}