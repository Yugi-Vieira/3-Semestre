
package rpg_test2;

class CajadoMagico implements Arma {
    @Override
    public void usar() {
        System.out.println("Usando cajado mágico");
    }
}
