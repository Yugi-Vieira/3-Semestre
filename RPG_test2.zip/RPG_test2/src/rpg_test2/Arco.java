package rpg_test2;

class Arco implements Arma {
    @Override
    public void usar() {
        System.out.println("Usando arco");
    }
}