package rpg_test2;

class AtaqueForte implements Habilidade {
    @Override
    public void usar() {
        System.out.println("Usando ataque forte");
    }
    @Override
    public String getName() {
        return "Ataque Forte";
    }
}