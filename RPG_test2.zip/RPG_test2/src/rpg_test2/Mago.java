package rpg_test2;

public class Mago implements RPGCharacter {
    private final CajadoMagico arma;
    private final MagiaFogo habilidade;
    private final RobeMagico equipamento;

    public Mago(CajadoMagico arma, MagiaFogo habilidade, RobeMagico equipamento) {
        this.arma = arma;
        this.habilidade = habilidade;
        this.equipamento = equipamento;
    }

    @Override
    public Arma getArma() {
        return arma;
    }

    @Override
    public Habilidade getHabilidade() {
        return habilidade;
    }

    @Override
    public Equipamento getEquipamento() {
        return equipamento;
    }

    public String getNome() {
        return "Mago";
    }
}