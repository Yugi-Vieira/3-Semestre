package rpg_test2;

public class MagoFactory extends CharacterFactory {
    @Override
    public RPGCharacter createCharacter() {
        CajadoMagico arma = new CajadoMagico();
        MagiaFogo habilidade = new MagiaFogo();
        RobeMagico equipamento = new RobeMagico();
        Mago mago = new Mago(arma, habilidade, equipamento);
        return mago;
    }
}