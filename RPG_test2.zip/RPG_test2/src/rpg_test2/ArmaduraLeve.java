package rpg_test2;

class ArmaduraLeve implements Equipamento {
    @Override
    public String getName() {
        return "Armadura Leve";
    }
}
