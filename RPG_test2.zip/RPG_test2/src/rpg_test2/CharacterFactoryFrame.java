package rpg_test2;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

class CharacterFactoryFrame extends JFrame {
    public CharacterFactoryFrame() {
        setTitle("Character Factory");
        setSize(300, 200);

        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(3, 1));

        JButton magoButton = new JButton("Create Mago");
        magoButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Mago mago = (Mago) new MagoFactory().createCharacter();
                JOptionPane.showMessageDialog(CharacterFactoryFrame.this,
                        "Equipment: " + mago.getEquipamento().getName() + "\n" +
                        "Attack: " + mago.getHabilidade().getName(),
                        "Mago Created",
                        JOptionPane.PLAIN_MESSAGE);
            }
        });
        panel.add(magoButton);

        JButton guerreiroButton = new JButton("Create Guerreiro");
        guerreiroButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Guerreiro guerreiro = (Guerreiro) new GuerreiroFactory().createCharacter();
                JOptionPane.showMessageDialog(CharacterFactoryFrame.this,
                        "Equipment: " + guerreiro.getEquipamento().getName() + "\n" +
                        "Attack: " + guerreiro.getHabilidade().getName(),
                        "Guerreiro Created",
                        JOptionPane.PLAIN_MESSAGE);
            }
        });
        panel.add(guerreiroButton);

        JButton arqueiroButton = new JButton("Create Arqueiro");
        arqueiroButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Arqueiro arqueiro = (Arqueiro) new ArqueiroFactory().createCharacter();
                JOptionPane.showMessageDialog(CharacterFactoryFrame.this,
                        "Equipment: " + arqueiro.getEquipamento().getName() + "\n" +
                        "Attack: " + arqueiro.getHabilidade().getName(),
                        "Arqueiro Created",
                        JOptionPane.PLAIN_MESSAGE);
            }
        });
        panel.add(arqueiroButton);

        add(panel);
    }
}
