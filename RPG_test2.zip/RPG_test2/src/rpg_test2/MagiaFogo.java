package rpg_test2;

class MagiaFogo implements Habilidade {
    @Override
    public void usar() {
        System.out.println("Usando magia de fogo");
    }
    @Override
    public String getName() {
        return "Magia Fogo";
    }
}
