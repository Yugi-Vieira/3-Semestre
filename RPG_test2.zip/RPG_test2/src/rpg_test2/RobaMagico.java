package rpg_test2;

class RobeMagico implements Equipamento {
    @Override
    public String getName() {
        return "Robe Mágico";
    }
}
