package rpg_test2;

public interface Arma {
    void usar();    
}
