package rpg_test2;

class Guerreiro implements RPGCharacter {
    private final Espada arma;
    private final AtaqueForte habilidade;
    private final ArmaduraPesada equipamento;

    public Guerreiro(Espada arma, AtaqueForte habilidade, ArmaduraPesada equipamento) {
        this.arma = arma;
        this.habilidade = habilidade;
        this.equipamento = equipamento;
    }

    @Override
    public Arma getArma() {
        return arma;
    }

    @Override
    public Habilidade getHabilidade() {
        return habilidade;
    }

    @Override
    public Equipamento getEquipamento() {
        return equipamento;
    }
}