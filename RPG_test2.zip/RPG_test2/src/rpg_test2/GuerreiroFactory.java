package rpg_test2;

class GuerreiroFactory extends CharacterFactory {

    GuerreiroFactory() {
    }
    @Override
    public RPGCharacter createCharacter() {
        return (RPGCharacter) new Guerreiro(new Espada(), new AtaqueForte(), new ArmaduraPesada());
    }
}