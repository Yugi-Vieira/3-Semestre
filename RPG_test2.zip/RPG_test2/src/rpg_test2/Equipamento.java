package rpg_test2;

public interface Equipamento {
     String getName();
}
