package rpg_test2;

class ArmaduraPesada implements Equipamento {
    @Override
    public String getName() {
        return "Armadura Pesada";
    }
}