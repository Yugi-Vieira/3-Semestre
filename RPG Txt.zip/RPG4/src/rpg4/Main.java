package rpg4;

public class Main {
    public static void main(String[] args) {
        //da start no jogo
        GameLogic.startGame();
    }
}
