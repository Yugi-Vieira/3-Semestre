package prova.pkg1;
public class Produto {
    private String nome;
    private double preco;
    private int estoq;

    public Produto(String nome, double preco, int estoq) {
        this.nome = nome;
        this.preco = preco;
        this.estoq = estoq;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public double getPreco() {
        return preco;
    }

    public void setPreco(double preco) {
        this.preco = preco;
    }

    public int getEstoq() {
        return estoq;
    }

    public void setEstoq(int estoq) {
        this.estoq = estoq;
    }
    
    
    public double CalcEstoq(){
        return estoq*preco;
}
}//fim main
