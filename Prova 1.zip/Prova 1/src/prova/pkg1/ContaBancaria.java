package prova.pkg1;
public class ContaBancaria {
    private int numconta;
    private double saldo;
    private double limcred;

    public ContaBancaria(int numconta, double saldo, double limcred) {
        this.numconta = numconta;
        this.saldo = saldo;
        this.limcred = limcred;
    }

    public double getSaldo() {
        return saldo;
    }
    
    public void depositar(double valor){
        
    saldo=(saldo+valor);
}
    public void sacar(double valor){
     saldo=(saldo-valor);
}

}