package prova.pkg1;

public class Analista extends Funcionario{

    public Analista(String nome, double salario) {
        super(nome, salario, "analista");
    }


    @Override
    public double getSalario(){
        return super.getSalario()*0.95;
    }

}


