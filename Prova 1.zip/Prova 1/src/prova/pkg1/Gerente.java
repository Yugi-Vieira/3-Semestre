package prova.pkg1;

public class Gerente extends Funcionario{
    private String setor;

    public Gerente(String nome, double salario) {
        super(nome, salario, "gerente");
    }
 
    @Override 
    public double getSalario(){
        return super.getSalario()*1.15;
    }

    public String getSetor() {
        return setor;
    }

    
}