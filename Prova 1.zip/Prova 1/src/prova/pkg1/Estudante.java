package prova.pkg1;
public class Estudante {
    private String nome;
    private int idade;
    private String turma;
    private double p1;
    private double p2;

    public Estudante(String nome, int idade, String turma, double p1, double p2) {
        this.nome = nome;
        this.idade = idade;
        this.turma = turma;
        this.p1 = p1;
        this.p2 = p2;
    }

    public String getNome() {
        return nome;
    }

    public int getIdade() {
        return idade;
    }

    public String getTurma() {
        return turma;
    }

    public double getP1() {
        return p1;
    }

    public double getP2() {
        return p2;
    }

    
    
    public double calcMedia(){
        return (p1+p2)/2;
    }
    
   
    
    
}
