package prova.pkg1;

public class Prova1 {

    public static void main(String[] args) {

      Funcionario G1 = new Gerente("Fabio", 3000);
      Funcionario A1 = new Analista("Fernando", 2000);  
      
      G1.PrintCC();
      A1.PrintCC();
      
      Vendedor v1 = new Vendedor ("Yugi" , "Supervisor", 2000, 5);
      v1.PrintCC();
      
      Estudante e1 = new Estudante ("Junior", 18, "ADS", 8, 7);
      Estudante e2 = new Estudante ("Iago", 20, "ADS", 5, 10);
      
        System.out.println(e1.getNome() +" tirou " + e1.calcMedia());
        System.out.println(e2.getNome()+" tirou " + e2.calcMedia());
     
     ContaBancaria c1 = new ContaBancaria(3, 1000, 10000);
     c1.depositar(1000);
     c1.sacar(500);
        System.out.println("O saldo d conta eh de " + c1.getSaldo());
     
     Produto p1 = new Produto("Banana", 5, 100);
     Produto p2 = new Produto ("Bala", 1, 12);
     
        System.out.println("O preco do estoque da" + p1.getNome() + " eh de " + p1.CalcEstoq());
        System.out.println("O preco do estoque da" + p1.getNome() + " eh de " + p2.CalcEstoq());
     
    }
    
    
    
}
