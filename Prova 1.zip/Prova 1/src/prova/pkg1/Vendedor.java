package prova.pkg1;
public class Vendedor {
    private String nome;
    private String cargo;
    private double salBase;
    private int totalVend;

    public Vendedor(String nome, String cargo, double salBase, int totalVend) {
        this.nome = nome;
        this.cargo = cargo;
        this.salBase = salBase;
        this.totalVend = totalVend;
    }
    
    
    
    public double calcSalLiq(){
        
        return salBase*totalVend;
}
    
    public void PrintCC(){
        System.out.println("Nome: "+nome+" Número de vendas: "+totalVend+" Salario liquido: "+calcSalLiq());
    }
}//fim vendedor
