package tarefa.pkg2;

public class Mamifero extends Animal {
    private String genero;

    public Mamifero(String nome, int idade, String genero) {
        super(nome, idade);
        this.genero = genero;
    }

    @Override
    public void fazerSom() {
        System.out.println("O mamífero emite um som típico.");
    }
}

