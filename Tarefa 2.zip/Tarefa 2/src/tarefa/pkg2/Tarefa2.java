package tarefa.pkg2;

public class Tarefa2 {

   
    public static void main(String[] args) {
        
         Cachorro cachorro = new Cachorro("Rex", 20, "Labrador");
        System.out.println("Nome: " + cachorro.getNome());
        System.out.println("Peso: " + cachorro.getPeso());
        System.out.println("Raca: " + cachorro.getRaca());
        
        Estudante estudante = new Estudante("Joao", 20, "123456");
        System.out.println("Nome: " + estudante.getNome());
        System.out.println("Idade: " + estudante.getIdade());
        System.out.println("Matricula: " + estudante.getMatrícula());
        
        Carro carro = new Carro("Gol", 2020, "Vermelho");
        System.out.println("Modelo: " + carro.getModelo());
        System.out.println("Ano: " + carro.getAno());
        System.out.println("Cor: " + carro.getCor());
        
        Gerente gerente = new Gerente("Maria", 5000, "Recursos Humanos");
        System.out.println("Nome: " + gerente.getNome());
        System.out.println("Salário: " + gerente.getSalario());
        System.out.println("Setor: " + gerente.getSetor());
        
        Mamifero mamifero = new Mamifero("Leão", 5, "Macho");
        mamifero.fazerSom();
    }
}