package tarefa.pkg2;

public class Estudante extends Pessoa {
    private String matricula;

    public Estudante(String nome, int idade, String matricula) {
        super(nome, idade);
        this.matricula = matricula;
    }

    public String getMatrícula() {
        return matricula;
    }

    public void setMatrícula(String matricula) {
        this.matricula = matricula;
    }
}
