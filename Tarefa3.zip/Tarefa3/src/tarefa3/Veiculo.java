package tarefa3;

public class Veiculo {
   private int ano;
   private String tipo;

    public Veiculo(int ano, String tipo) {
        this.ano = ano;
        this.tipo = tipo;
    }
   
   public void Acelerar(){
       System.out.println("Este veiculo está acelerando");
   }

    public int getAno() {
        return this.ano;
    }

    public String getTipo() {
        return this.tipo;
    }
   
   
   
}
