package tarefa3;

public class Circle extends Forma {
    private double raio;

    public Circle(double raio) {
        this.raio = raio;
    }
    @Override
    public double area() {
        return 3.14 * this.raio * this.raio;
    }

    @Override
    public double perimetro() {
        return 2 * 3.14 * this.raio;
    }
}