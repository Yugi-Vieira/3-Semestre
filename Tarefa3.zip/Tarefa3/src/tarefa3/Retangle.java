package tarefa3;
public class Retangle extends Forma {
    private double largura;
    private double altura;

    public Retangle(double largura, double altura) {
        this.largura = largura;
        this.altura = altura;
    }
    @Override
    public double area() {
        return this.largura * this.altura;
    }

    @Override
    public double perimetro() {
        return 2 * (this.largura + this.altura);
    }
}