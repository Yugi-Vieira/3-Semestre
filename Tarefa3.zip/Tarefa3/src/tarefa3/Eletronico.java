package tarefa3;

public class Eletronico extends Produto {
    public Eletronico(String nome, double preco) {
        super(nome, preco);
    }

    @Override
    public double calculaDesconto(double desconto) {
        return super.calculaDesconto(desconto * 0.25);
    }
}