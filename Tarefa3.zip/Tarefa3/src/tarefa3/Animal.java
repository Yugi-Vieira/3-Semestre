package tarefa3;

public class Animal {
    public void emitirSom() {
        System.out.println("Um estranho som e ouvido...");
    }

    public void mover() {
        System.out.println("Algo parece ter se mexido...");
    }
}
