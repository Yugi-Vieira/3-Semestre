package tarefa3;

public class Produto {
    protected String nome;
    protected double preco;

    public Produto(String nome, double preco) {
        this.nome = nome;
        this.preco = preco;
    }

    public double calculaDesconto(double desconto) {
        return this.preco - (this.preco * desconto);
    }

    public String getNome() {
        return this.nome;
    }
}