package tarefa3;

public class Triangle extends Forma {
    private double base;
    private double altura;
    private double lado1;
    private double lado2;

    public Triangle(double base, double altura, double lado1, double lado2) {
        this.base = base;
        this.altura = altura;
        this.lado1 = lado1;
        this.lado2 = lado2;
    }

    @Override
    public double area() {
        return 0.5 * this.base * this.altura;
    }

    @Override
    public double perimetro() {
        return this.base + this.lado1 + this.lado2;
    }
}