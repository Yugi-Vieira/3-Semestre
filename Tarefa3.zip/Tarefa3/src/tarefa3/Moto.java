package tarefa3;

public class Moto extends Veiculo{
    private String marca;

    public Moto(int ano, String tipo, String marca) {
        super(ano, tipo);
        this.marca = marca;
    }

    public String getMarca() {
        return marca;
    }
    
    @Override
    public void Acelerar(){
        System.out.println("after 3 seconds this " + this.getMarca() + " " + this.getTipo() + " reached 100 miles per hour! (XoX) wow thats crazy");
    }
}
