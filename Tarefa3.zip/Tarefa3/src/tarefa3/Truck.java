package tarefa3;

public class Truck extends Veiculo{
    private String marca;

    public Truck(int ano, String tipo, String marca) {
        super(ano, tipo);
        this.marca = marca;
    }

    public String getMarca() {
        return marca;
    }
    
    @Override
    public void Acelerar(){
        System.out.println("after 8 seconds this " + this.getMarca() + " " + this.getTipo() + " reached 60 miles per hour (-_-) thats boring...");
    }
}