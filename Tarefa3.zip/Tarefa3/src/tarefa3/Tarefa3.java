package tarefa3;

public class Tarefa3 {

    public static void main(String[] args) {
        Moto hayabusa = new Moto(2005,"Bike","Suzuki");
        hayabusa.Acelerar();
        
        Carro civic = new Carro(1998,"Coupe","Honda");
        civic.Acelerar();
        
        Truck Meca = new Truck(1995,"20m Truck","Mercedes");
        Meca.Acelerar();
        
        
        Circle circulo = new Circle(5);
            System.out.println("Area of the circle: " + circulo.area());
            System.out.println("Perimeter of the circle: " + circulo.perimetro());
        
        Retangle retangulo = new Retangle(4, 6);
                System.out.println("Area of the rectangle: " + retangulo.area());
                System.out.println("Perimeter of the rectangle: " + retangulo.perimetro());
        
        Triangle triangulo = new Triangle(3, 4, 5, 5);
             System.out.println("Area of the triangle: " + triangulo.area());
             System.out.println("Perimeter of the triangle: " + triangulo.perimetro());
                
        Gerente victor = new Gerente("Victor",4000);
        System.out.println(victor.getNome() +" e um gernete e tem "+victor.Bonus()+" de bonus");
        
        Dev Ector = new Dev("Ector",3500);
        System.out.println(Ector.getNome() +" e um gernete e tem "+Ector.Bonus()+" de bonus");
    
    
        Animal cachorro = new Cachorro();
         cachorro.emitirSom();
         cachorro.mover();
        
        Animal gato = new Gato();
         gato.emitirSom();
         gato.mover();
        
        Animal passaro = new Passaro();
         passaro.emitirSom();
         passaro.mover();
        
        Produto eletronico = new Eletronico("Televisao", 800.00);
        System.out.println("Eletronico:");
        System.out.println("Desconto de 10%: " + String.format("%.2f", eletronico.calculaDesconto(0.10)) + " R$");
        System.out.println("Desconto de 20%: " + String.format("%.2f", eletronico.calculaDesconto(0.20)) + " R$");
        
        Produto alimento = new Alimento("Batata", 10.00);
        System.out.println("Alimento:");
        System.out.println("Desconto de 10%: " + String.format("%.2f", alimento.calculaDesconto(0.10)) + " R$");
        System.out.println("Desconto de 20%: " + String.format("%.2f", alimento.calculaDesconto(0.20)) + " R$");
    }
    
}
