package tarefa3;

public class Carro extends Veiculo{
    private String marca;

    public Carro(int ano, String tipo, String marca) {
        super(ano, tipo);
        this.marca = marca;
    }

    public String getMarca() {
        return marca;
    }
    
    @Override
    public void Acelerar(){
        System.out.println("after 5 seconds this " + this.getMarca() + " " + this.getTipo() + " reached 70 miles per hour, enough (0c0)");
    }
}