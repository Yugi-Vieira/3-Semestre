package tarefa3;

public class Passaro extends Animal {
   
    @Override
    public void emitirSom() {
        System.out.println("twiuu");
    }

    
    @Override
    public void mover() {
        System.out.println("O passaro saiu voando");
    }
}