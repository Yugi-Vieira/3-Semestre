package tarefa3;

public class Dev extends Funcionario{
    public Dev(String nome, double salario) {
        super(nome, salario);
    }
    
    public String getNome(){
        return super.getNome();
    }
    
    public double getSalario(){
        return super.getSalario();
    }
    
    @Override
    public double Bonus(){
        return super.Bonus()+200;
    }
}
