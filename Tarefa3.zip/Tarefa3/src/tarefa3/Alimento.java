package tarefa3;

public class Alimento extends Produto {
    public Alimento(String nome, double preco) {
        super(nome, preco);
    }

    @Override
    public double calculaDesconto(double desconto) {
        return super.calculaDesconto(desconto * 0.1);
    }
}