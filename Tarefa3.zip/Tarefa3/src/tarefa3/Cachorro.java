package tarefa3;

public class Cachorro extends Animal {
    @Override
    public void emitirSom() {
        System.out.println("Au au au");
    }
    
    @Override
    public void mover() {
        System.out.println("O cachorro correu");
    }
}